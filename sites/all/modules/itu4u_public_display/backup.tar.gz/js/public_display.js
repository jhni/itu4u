
/******

Updates the AirNotes display on public displays. Must be run on either google chorme or safari

*******/
var macs_in_zone = new Array();

$.fn.airnotesupdate = function(){
	
	$.getJSON("http://pit.itu.dk/airnotes/sites/all/modules/public_display/php/blip.php?zone=" + blipzone +"&jsoncallback=?",
		function(devices){  
			
			var located = false;
			for(var i= 0; i<macs_in_zone.length;i++){
				located = false;
				for(var j= 0; j<devices.length;j++){	
					
					if(devices[j]['terminal-id'] == macs_in_zone[i]){
						located = true;
						break;
					}
				}

				if(!located){
					$("." + macs_in_zone[i]).fadeOut(1500, function(){$(this).remove();});
				}
				
			}
	
			// Reset macs_in_zone
			macs_in_zone = new Array();
			
			$.each(devices, function(i,mac){
			
				macs_in_zone.push(mac['terminal-id']);
											
				$.getJSON("http://pit.itu.dk/airnotes/notes/json/"+mac['terminal-id'],
					function(notes){	
						$.each(notes, function(i,airnotes){
							$.each(airnotes, function(i,airnote){	
							
								//Does the element exist ?
								if($('#notes #'+ airnote.node.nid).length == 0){
										
									// Display nodes 											
					 				var image = $('<div id="'+airnote.node.nid+'"><img src="'+airnote.node.Image+'" width="50%" align="middle" style="display:block;margin-right:auto;margin-left:auto;" />'+airnote.node.body+'<p>Posted by <b>'+ airnote.node.user_name+'</b></p><br/>'+ airnote.node.rating+'</div>').attr("class", "note " + mac['terminal-id']);
				 					image.css("top", Math.floor(Math.random()*50+1)+"%").css("left", Math.floor(Math.random()*60+1)+"%");
				 					var random = Math.floor(Math.random()*60+1)-30;
				 					image.css("-moz-transform", "rotate("+random+"deg)");
				 					image.css("-webkit-transform", "rotate("+random+"deg)");
				 					image.css("-transform", "rotate("+random+"deg)");
				 					image.hide().appendTo("#notes").fadeIn("slow");	
			 					}
			 					
			 						// Display auther	
			 					if($('#users #'+ airnote.node.user_id).length == 0){	
			 						$('<div id="'+ airnote.node.user_id +'">' + airnote.node.user_name + "</div>").attr("class", "name " + mac['terminal-id']).hide().appendTo("#users").fadeIn("slow");
			 					}			 									
							});					
						});			
				});
			});	
		});			 
};

/******

 Update data every 3 sec.

*******/
$(document).everyTime(3000, function(i){$(document).airnotesupdate();}, 0);