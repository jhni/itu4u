#!/bin/sh
# $Id: cron-curl.sh,v 1.3 2006/08/22 07:38:24 dries Exp $

curl --silent --compressed http://example.com/cron.php
