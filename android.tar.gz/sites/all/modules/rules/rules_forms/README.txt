$Id: README.txt,v 1.1.2.3 2009/08/16 13:59:56 klausi Exp $

Rules Forms Module
------------------
maintained by Klaus Purer <klaus.purer@gmail.com>

This module allows you to manipulate/customize forms on your site with Rules. 


Installation
------------

The Rules Forms module ships with the Rules module - so copy the whole Rules directory
to your module directory and activate the rules forms module.


Getting started
---------------

This is a short usage guide to build Rules on you forms:

 * Go to the "Form events" page in the Rules administration menu (admin/rules/forms).
 * Select the checkbox "Enable event activation messages on forms" and hit the "Save
   settings" button.
 * Go to the form on your site that you would like to customize with Rules, e.g.
   go to 'node/add/story' to enable events on the "Create Story" form.
 * On the top of the page you see a drupal message with a link to activate events
   for the form, click it.
 * Confirm the activation by clicking the "Activate" button.
 * Go to the "Triggered rules" admin page (admin/rules/trigger) and click the "Add
   a new rule" tab.
 * Fill out the label, choose a form event by selecting one in the "Rules Forms"
   group and confirm with "Save changes".
 * Now you can add conditions and actions to react on the form event.


Form element conditions and actions
-----------------------------------

The Rules forms module allows you to manipulate single form elements, where you
need the ID of the element. This guide shows you you how to find them.

 * Go to the "Form events" page in the Rules administration menu (admin/rules/forms).
 * Make sure that you have activated events on your target form, it should be listed
   on the page.
 * Select the checkbox "Display form element IDs" and hit the "Save settings" button.
 * Go to the target form on your site, where you will see the form element ID below
   each form element.
 * Copy the ID of the form element you would like to examine or manipulate, e.g.
   copy "body_field[body]" on the "Create Story" form if you want to do something
   with the node body textarea.
 * Paste this ID when you create a condition or an action which requires a form
   element ID.
