Author: 
Eric Wright, eric.wright@bluevestconsulting.com

INSTALLATION

1. Extract to the site/all/modules
2. Enable in Administer > Modules (admin/build/modules).

CONFIGURATION

1. Edit you content types to specify the required number of points for each type

That's it!
